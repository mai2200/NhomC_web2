<?php
define('BASE_URL', 'php-training');
define('PATH_URL', 'http://localhost/php-training/');
